*PADS-LIBRARY-PART-TYPES-V9*

TLV75733PDBVR SOT95P280X145-5N I ANA 7 1 0 0 0
TIMESTAMP 2026.03.12.14.09.51
"Mouser Part Number" 595-TLV75733PDBVR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TLV75733PDBVR?qs=y6ZabgHbY%252BwAAzSntTW34w%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TLV75733PDBVR
"Description" LDO Voltage Regulators 1A Low-IQ Small-Size Low-Dropout (LDO) Regulator 5-SOT-23 -40 to 125
"Datasheet Link" http://www.ti.com/lit/gpn/tlv757p
"Geometry.Height" 1.45mm
GATE 1 5 0
TLV75733PDBVR
1 0 P IN
2 0 G GND
3 0 L EN
4 0 U NC
5 0 S OUT

*END*
*REMARK* SamacSys ECAD Model
1251656/1714094/2.50/5/3/Power Supply
